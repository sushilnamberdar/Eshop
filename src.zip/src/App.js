import logo from './logo.svg';
import './App.css';
import Navbar from './Component/Navbar';
import NewApi from './Component/NewApi';
import Offcanvass from './Component/Offcanvass';



function App() {
  return (
    <>
    <Navbar/>
    <Offcanvass/>
    <NewApi/>
   
    </>

  );
}

export default App;
