import React, { useEffect, useState } from 'react';
import axios from 'axios';

const NewApi = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios.get("https://fakestoreapi.com/products").then((response) => {
      setData(response.data);
    });
  }, []);

  const toggleDescription = (index) => {
    const newData = [...data];
    newData[index].showDescription = !newData[index].showDescription;
    setData(newData);
  };

  return (
    <div className="container mx-auto py-8 mt-40">
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {data.map((item, index) => (
          <div key={index} className="border border-gray-300 rounded p-4">
            <div>{item.title}</div>
            <div className='w-[160px]'>
              <img src={item.image} alt={item.title} className='object-contain' />
            </div>
            <div>Rating: {item.rating.rate}/5</div>
            <div>Price: {item.price} $</div>
            <button className='border border-2 p-2 mr-1'>Buy Now</button>
            <button className='border border-2 p-2 mr-1'>Add To Cart</button>
            <button className='border border-2 p-2 mt-2' onClick={() => toggleDescription(index)}>
              {item.showDescription ? 'Less' : 'More'}
            </button>
            {item.showDescription && <div>{item.description}</div>}
          </div>
        ))}
      </div>
    </div>
  );
};

export default NewApi;
