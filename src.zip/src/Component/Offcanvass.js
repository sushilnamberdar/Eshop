import { Checkbox, Radio } from '@headlessui/react';
import React, { useState, useEffect } from 'react';
import { Button, Offcanvas } from 'react-bootstrap';

const Offcanvass = () => {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(prevShow => !prevShow);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (show && !event.target.closest('.offcanvas')) {
        setShow(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [show]);

  return (
    <div>
      <Button className="mt-10 bg-pink-800 ml-10 fixed" variant="primary" onClick={handleShow}>
        Filters
      </Button>

      <Offcanvas show={show} onHide={handleClose} placement="start" scroll={true} backdrop={false}>
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>Filters</Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body>
          <div className='grid ml-10'>
            <label htmlFor="pricerange" className='mt-10'>Price Range</label>
            <div >
              <input type="range" id="pricerange" min="5" max="2000" defaultValue="10" />
            </div>
            <span> 200$ </span>
            <label htmlFor="ratingrange" className='mt-4'>Rating</label>
            <div className=''>

              <input type="range" id="ratingrange" min="2" max="5" defaultValue="3" />
            </div>
            <span> 3<span>-5</span></span>

            <h5>Category</h5>
            <div className='grid grid-cols-2  gap-2 -ml-20 mt-3'>
              <input type='checkbox' />
              <span>men's clothing</span>
              <input type='checkbox' />
              <span>jewelery</span>
              <input type='checkbox' />
              <span>electronics</span>
              <input type='checkbox' />
              <span>women's clothing</span>
            </div>

          </div>
          {/* <div className='flex  justify-center  mt-10'>
            <Button>Done</Button>
          </div>  */}
        </Offcanvas.Body>
      </Offcanvas>
    </div>
  );
};

export default Offcanvass;
